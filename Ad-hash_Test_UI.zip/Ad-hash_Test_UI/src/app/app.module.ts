import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MaterialModule} from'./material/material.module';
// import { HelloComponent } from './hello.component';
import { TrackModalComponent } from './common/track-modal/track-modal.component';
import { MatTableComponent } from './common/track-modal/mat-table/mat-table.component';

@NgModule({
  declarations: [
    AppComponent,
    TrackModalComponent,
    MatTableComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  exports: [
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
