import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TrackModalComponent } from '../track-modal.component';

export interface PeriodicElement {
  product_name: string;
  position: number;
  o_Date: string;
  symbol: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, product_name: 'Hydrogen', o_Date:'11/21/2020', symbol: 'H'},
  {position: 2, product_name: 'Helium', o_Date:'12/21/2020', symbol: 'He'},
  {position: 3, product_name: 'Lithium', o_Date: ' 13/21/2020', symbol: 'Li'},
  {position: 4, product_name: 'Beryllium', o_Date:  '14/21/2020', symbol: 'Be'},
  {position: 5, product_name: 'Boron', o_Date:  '11/21/2020', symbol: 'B'},
  {position: 6, product_name: 'Carbon', o_Date:  '11/21/2020', symbol: 'C'},
  {position: 7, product_name: 'Nitrogen', o_Date:  '12/21/2020', symbol: 'N'},
  {position: 8, product_name: 'Oxygen', o_Date:  '11/21/2020', symbol: 'O'},
  {position: 9, product_name: 'Fluorine', o_Date:  '11/21/2020', symbol: 'F'},
  {position: 10, product_name: 'Neon', o_Date:  '11/21/2020', symbol: 'Ne'},
];

@Component({
  selector: 'app-mat-table',
  templateUrl: './mat-table.component.html',
  styleUrls: ['./mat-table.component.scss']
})
export class MatTableComponent implements OnInit {
  
  displayedColumns: string[] = ['position', 'product_name', 'o_Date', 'Action'];
  dataSource = ELEMENT_DATA;

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

 
  }

  openDialog() {
    const dialogRef = this.dialog.open(TrackModalComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

}
