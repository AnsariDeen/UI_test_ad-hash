import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-track-modal',
  templateUrl: './track-modal.component.html',
  styleUrls: ['./track-modal.component.scss']
})
export class TrackModalComponent implements OnInit {

  public selectedItem= false;
 
  showDiv = {
    one : true,
    two : false,
    three : false,
    four : false,
    five : false,
    six : false
  }

  orders: any = [
    { 
    status:"Confirmed Order",date:"Tue, June 25", 
    status1:"Processing Order",date1:"Tue, June 26",
    status2:"Quality Check",date2:"Tue, June 27",
    status3:"Dipatched Item",date3:"Tue, June 28",
    status4:"Order Delivered",date4:"Tue, June 29",
    active:true,inactive:false
  }
 ];
 
public shouldShow = true;
  
  constructor() { }

  ngOnInit(): void { 
  }

  status: boolean = false;
  status1: boolean = false;
  status2: boolean = false;
  status3: boolean = false;
  status4: boolean = false;
  active: boolean = true;
  inactive: boolean = false;

  
  step(){
      // this.status = !this.status;  
      this.showDiv.one = false;
       this.showDiv.two = !this.showDiv.two; 
       this.showDiv.three = false;
       this.showDiv.four = false;
       this.showDiv.five = false;     
  }

  step2(){
    // this.status1 = !this.status1;  
    // this.status = !this.status;
    this.showDiv.one = !this.showDiv.one;
    this.showDiv.two = false;
    this.showDiv.three = false;
    this.showDiv.four = false;
    this.showDiv.five = false;
  }

  step3(){
    // this.status1 = !this.status1;  
    // this.status2 = !this.status2;  
    this.showDiv.two = false;
    this.showDiv.one = false; 
    this.showDiv.three = !this.showDiv.three;
    this.showDiv.four = false;
    this.showDiv.five = false;
  }

  step4(){
    // this.status2 = !this.status2;  
    // this.status3 = !this.status3; 
    this.showDiv.two = !this.showDiv.two; 
    this.showDiv.three = false; 
    this.showDiv.one = false;
    this.showDiv.four = false;
    this.showDiv.five = false;

  }
  step5(){
    this.showDiv.four = !this.showDiv.four; 
    this.showDiv.two = false; 
    this.showDiv.one = false;
    this.showDiv.three = false;
    this.showDiv.five = false;

  }

  step6(){
    this.showDiv.five = !this.showDiv.five; 
    this.showDiv.two = false; 
    this.showDiv.one = false;
    this.showDiv.three = false;
    this.showDiv.four = false;
  }
}
